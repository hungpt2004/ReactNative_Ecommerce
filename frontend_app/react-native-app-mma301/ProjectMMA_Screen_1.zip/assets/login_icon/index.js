import Google from "./Google_icon.svg";
import Facebook from "./Facebook.svg";
import Apple from "./Apple.svg";

export { Google, Facebook, Apple };
