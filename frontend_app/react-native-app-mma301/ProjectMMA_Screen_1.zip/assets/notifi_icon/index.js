import Type1 from "./Type1.svg";
import Type2 from "./Type2.svg";
import Type3 from "./Type3.svg";

export { Type1, Type2, Type3 };
