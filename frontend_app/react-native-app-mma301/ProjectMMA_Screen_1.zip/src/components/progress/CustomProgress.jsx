import React from 'react'
import { StyleSheet } from 'react-native'

export const CustomProgress = ({rating, progress}) => {
  return (
    <div>

    </div>
  )
}

const styles = StyleSheet.create({
   container: {
      
   }
})
